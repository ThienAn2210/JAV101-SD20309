package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connectdao {

    protected static Connection conn = null; // Khai báo

    static {
        try {
            // 1. Load Driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            // 2. Thông tin kết nối SQL Server
            String url = "jdbc:sqlserver://localhost:1433;databaseName=lab6_java3;encrypt=false;trustServerCertificate=true;";
            String user = "sa"; 
            String pass = "1234567"; // ⚠️ KIỂM TRA MẬT KHẨU NÀY CÓ ĐÚNG KHÔNG

            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("✅ KẾT NỐI DB THÀNH CÔNG.");
        } 
        catch (Exception ex) {
            // Nếu có lỗi, in ra lỗi chi tiết để biết chính xác là lỗi gì (Driver, URL, hay Mật khẩu)
            System.err.println("❌ LỖI KẾT NỐI DB:");
            ex.printStackTrace();
        }
    }
}