package poly.com.dao;

import poly.com.entity.News;
import java.util.List;




public interface NewsDAO {
    List<News> findAll();
    List<News> findLatest(int top);
    List<News> findHot(int top);
    List<News> findByCategory(String categoryId);
    News findById(String id);
}
