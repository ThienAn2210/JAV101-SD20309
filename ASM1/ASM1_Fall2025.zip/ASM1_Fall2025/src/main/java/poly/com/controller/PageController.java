package poly.com.controller;

import java.io.IOException;
import java.util.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet({ "/","/home", "/category", "/detail", "/newsletter" })
public class PageController extends HttpServlet {

	List<Map<String, String>> news = new ArrayList<>();

	@Override
	public void init() throws ServletException {
		// Thêm dữ liệu mẫu
		addNews("Văn hóa", "Lễ hội mùa xuân 2025 diễn ra sôi động",
				"Hàng triệu du khách tham gia lễ hội trong không khí vui tươi", "/images/img1.jpg");

		addNews("Thể thao", "U23 Việt Nam thắng đậm 4-0", "U23 VN có màn trình diễn thuyết phục trước đối thủ mạnh",
				"/images/img2.jpg");

		addNews("Kinh tế", "Giá vàng vượt mốc 80 triệu/lượng", "Thị trường vàng biến động mạnh trong ngày hôm nay",
				"/images/img3.jpg");

		addNews("Pháp luật", "Triệt phá đường dây lừa đảo công nghệ cao", "Công an bắt giữ 12 đối tượng liên quan",
				"/images/img4.jpg");
	}

	// Thêm dữ liệu tin tức
	private void addNews(String category, String title, String summary, String img) {
		Map<String, String> n = new HashMap<>();
		n.put("id", UUID.randomUUID().toString());
		n.put("category", category);
		n.put("title", title);
		n.put("summary", summary);
		n.put("img", img);
		news.add(n);
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// 1. Hiển thị loại tin
		List<String> categories = Arrays.asList("Văn hóa", "Pháp luật", "Thể thao", "Kinh tế");
		req.setAttribute("categories", categories);

		// 2. 5 bản tin hot nhất
		req.setAttribute("hotNews", Arrays.asList("Hot 1", "Hot 2", "Hot 3", "Hot 4", "Hot 5"));

		// 3. 5 bản tin mới nhất
		req.setAttribute("newestNews", Arrays.asList("Mới 1", "Mới 2", "Mới 3", "Mới 4", "Mới 5"));

		// 4. 5 bản tin đã xem gần đây (giả lập cookie/session)
		req.setAttribute("recentNews", Arrays.asList("Đã xem 1", "Đã xem 2", "Đã xem 3", "Đã xem 4", "Đã xem 5"));

		// ROUTING
		String url = req.getServletPath();

		switch (url) {

		// --- TRANG CHỦ ---
		case "/home":
			req.setAttribute("view", "/ASM/home.jsp");
			break;

		// --- TRANG LOẠI TIN ---
		case "/category":
		    String cat = req.getParameter("name");

		    List<Map<String, String>> filtered =
		            news.stream()
		                .filter(n -> n.get("category").equals(cat))
		                .toList();

		    req.setAttribute("category", cat);
		    req.setAttribute("newsList", filtered);
		    req.setAttribute("related", news); // để detail dùng
		    req.setAttribute("view", "/ASM/category.jsp");
		    break;


		// --- TRANG CHI TIẾT ---
		case "/detail":
		    String id = req.getParameter("id");

		    Map<String, String> item = news.stream()
		            .filter(n -> n.get("id").equals(id))
		            .findFirst()
		            .orElse(null);

		    req.setAttribute("item", item);
		    req.setAttribute("related", news);
		    req.setAttribute("view", "/ASM/detail.jsp");
		    break;

		default:
			req.setAttribute("view", "/ASM/home.jsp");
		}

		req.getRequestDispatcher("/ASM/form.jsp").forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// xử lý newsletter
		if (req.getServletPath().equals("/newsletter")) {
			String email = req.getParameter("email");
			System.out.println("Email đăng ký: " + email);
		}

		doGet(req, resp);
	}
}
