package poly.com.dao;
import poly.com.entity.Category;



import java.util.List;
public interface CategoryDAO {
	List<Category> findAll();
	Category findById(String id);

}
