package poly.com.dao;

import poly.com.entity.User;

import java.util.List;




public interface UserDAO {
    User findById(String id);
    List<User> findAll();
}
