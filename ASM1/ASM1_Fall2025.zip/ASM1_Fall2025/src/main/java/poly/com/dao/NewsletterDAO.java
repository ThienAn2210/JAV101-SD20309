package poly.com.dao;
import poly.com.entity.Newsletter;
import java.util.List;


public interface NewsletterDAO {
    void insert(Newsletter n);
    List<Newsletter> findAll();
}
