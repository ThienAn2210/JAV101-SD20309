package poly.com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCUtil {

    private static final String URL = 
        "jdbc:sqlserver://localhost:1433;"
        + "databaseName=ASM_java3_Fall2025;"
        + "encrypt=false;"
        + "trustServerCertificate=true";

    private static final String USER = "sa";
    private static final String PASS = "1234567";  // đổi theo SQL của bạn

    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println(">> SQLServer Driver loaded!");
        } catch (Exception e) {
            System.err.println(">> Không thể load SQLServer Driver!");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        try {
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            System.out.println(">> KẾT NỐI DATABASE THÀNH CÔNG!");
            return conn;
        } catch (Exception e) {
            System.err.println(">> LỖI KẾT NỐI DATABASE: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
}
