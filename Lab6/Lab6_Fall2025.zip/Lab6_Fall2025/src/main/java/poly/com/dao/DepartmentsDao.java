package poly.com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Department;

public class DepartmentsDao {
    Connection conn = null;

    public DepartmentsDao() {
        conn = Connectdao.getConnection();
    }

    // Thêm mới
    public void insertDepartment(String id, String name, String description) {
        try {
        	String sql = "INSERT INTO Departments(id,Name,Description) VALUES (?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, description);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // Cập nhật
    public void updateDepartment(String id, String name, String description) {
        try {
            String sql = "UPDATE Departments SET Name=?, Description=? WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, description);
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // Tìm theo ID
    public Department findDepartmentById(String id) {
        try {
            String sql = "SELECT * FROM Departments WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Department(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // Load toàn bộ danh sách
    public List<Department> selectAll() {
        List<Department> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Departments";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Department(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3)));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
    
 // Xóa phòng ban theo ID
    public void deleteDepartment(String id) {
        try {
            String sql = "DELETE FROM Departments WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
            System.out.println(">> Xóa thành công: " + id);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(">> Xóa thất bại!");
        }
    }

}
