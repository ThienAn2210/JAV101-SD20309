package poly.com.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Department;
import poly.com.dao.DepartmentsDao;

@WebServlet({
	"/Departments", "/Departments/loadall", "/Departments/add",
	"/Departments/delete", "/Departments/edit", "/Departments/find", "/Departments/update"
})
public class DeparmentsController extends HttpServlet {

	// XÓA
	protected void deleteDepartments(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		new DepartmentsDao().deleteDepartment(id);
		System.out.println(">>> Xóa thành công: " + id);
	}

	// POST xử lý thêm, cập nhật, tìm
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		DepartmentsDao dao = new DepartmentsDao();

		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String description = req.getParameter("description");

		// Thêm mới
		if (uri.contains("add")) {
			dao.insertDepartment(id, name, description);
			System.out.println(">>> Thêm thành công!");

		// Cập nhật
		} else if (uri.contains("update")) {
			dao.updateDepartment(id, name, description);
			System.out.println(">>> Cập nhật thành công!");

		// Tìm phòng ban
		} else if (uri.contains("find")) {
			Department dept = dao.findDepartmentById(req.getParameter("txttim"));
			if (dept != null) {
				req.setAttribute("departmentEdit", dept); // Đổ vào form
				System.out.println(">>> Tìm thấy phòng ban!");
			} else System.out.println(">>> Không tìm thấy!");
		}

		// Load danh sách về trang GUI
		List<Department> list = dao.selectAll();
		req.setAttribute("departments", list);
		req.getRequestDispatcher("/Departments/DepartmentGui.jsp").forward(req, resp);
	}


	// GET xử lý Edit / Delete / Load all
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		DepartmentsDao dao = new DepartmentsDao();

		// Edit -> đổ dữ liệu phòng ban lên form
		if (uri.contains("edit")) {
			String id = req.getParameter("id");
			Department dept = dao.findDepartmentById(id);
			req.setAttribute("departmentEdit", dept);
		}

		// Delete
		else if (uri.contains("delete")) {
			deleteDepartments(req, resp);
		}

		// Load full table
		List<Department> list = dao.selectAll();
		req.setAttribute("departments", list);
		req.getRequestDispatcher("/Departments/DepartmentGui.jsp").forward(req, resp);
	}
}
