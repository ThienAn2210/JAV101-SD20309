package poly.com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connectdao {

    protected static Connection conn;

    public Connectdao() {
        try {
            String url = "jdbc:sqlserver://localhost:1433;"
                        + "databaseName=lab6_java3_csdl;"
                        + "encrypt=false;trustServerCertificate=true;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(url, "sa", "1234567");
            System.out.println("Kết nối thành công!");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // 🔥 THÊM MỚI HÀM NÀY — ĐỂ DAO KHÁC GỌI TỚI
    public static Connection getConnection() {
        if (conn == null) {
            new Connectdao(); // tự động tạo kết nối nếu chưa có
        }
        return conn;
    }
}
