package poly.com.controller;

public class bai4 {
	private String fullname;
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	private boolean gender;
	private String country;
	
	public bai4(String fullname, boolean gender, String country) {
		super();
		this.fullname = fullname;
		this.gender = gender;
		this.country = country;
	}
	
	public bai4() {
		
	}
	

}
