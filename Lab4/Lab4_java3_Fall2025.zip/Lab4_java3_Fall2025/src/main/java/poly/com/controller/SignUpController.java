package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import poly.com.entity.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/signup")
public class SignUpController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user = new User();
        user.setAccount(" ");
        user.setGender(true);
        user.setCountry(" ");

        req.setAttribute("user", user);
        req.getRequestDispatcher("/signup.jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user = new User();
        user.setAccount(req.getParameter("account"));
        user.setPassword(req.getParameter("password"));
        user.setGender("true".equals(req.getParameter("gender")));
        user.setMarried(req.getParameter("married") != null);
        user.setCountry(req.getParameter("country"));
        user.setHobbies(req.getParameterValues("hobbies"));
        user.setNote(req.getParameter("note"));
        
        List<String> errors = validate(user);
        if (!errors.isEmpty()) {
            req.setAttribute("errors", errors);
            req.getRequestDispatcher("/signup.jsp").forward(req, resp);
            return;
        }


        System.out.println("Tài khoản: " + user.getAccount());
        System.out.println("Mật khẩu: " + user.getPassword());
        System.out.println("Giới tính: " + (user.isGender() ? "Nam" : "Nữ"));
        System.out.println("Đã kết hôn: " + (user.isMarried() ? "Đã kết hôn" : "Chưa kết hôn"));
        System.out.println("Quốc tịch: " + user.getCountry());
        System.out.print("Sở thích: ");
        if (user.getHobbies() != null) {
            for (String h : user.getHobbies()) {
                System.out.println(h + " ");
            }
        }
        System.out.println();

        req.setAttribute("user", user);
        req.setAttribute("message", "Đăng ký thành công!");
        req.getRequestDispatcher("/signup.jsp").forward(req, resp);
	}
	
	private List<String> validate(User user) {
	    List<String> errors = new ArrayList<>();
	    if (user.getAccount() == null || user.getAccount().isBlank()) {
	        errors.add("Tên tài khoản không được để trống");
	    }
	    if (user.getPassword() == null || user.getPassword().isBlank()) {
	        errors.add("Mật khẩu không được để trống");
	    }
	    return errors;
	}

	
}
