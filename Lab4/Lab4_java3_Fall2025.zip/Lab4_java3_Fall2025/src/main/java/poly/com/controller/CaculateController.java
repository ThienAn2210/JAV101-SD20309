package poly.com.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/caculate/add", "/caculate/sub"})
public class CaculateController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("message", "Nhập số và chọn phép tính");
        req.getRequestDispatcher("/caculate.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html; charset=UTF-8");

        String a = req.getParameter("a");
        String b = req.getParameter("b");
        String path = req.getServletPath();
        double c = 0;

        try {
            if (path.endsWith("/add")) {
                c = Double.parseDouble(a) + Double.parseDouble(b);
                req.setAttribute("message", a + " + " + b + " = " + c);
            } else {
                c = Double.parseDouble(a) - Double.parseDouble(b);
                req.setAttribute("message", a + " - " + b + " = " + c);
            }
        } catch (NumberFormatException e) {
            req.setAttribute("message", "Vui lòng nhập số hợp lệ!");
        }

        req.getRequestDispatcher("/caculate.jsp").forward(req, resp);
    }
}
